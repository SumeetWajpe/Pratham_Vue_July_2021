<template>
  <v-app m>
    <v-app-bar app color="primary" dark>
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Name"
          class="shrink mt-1 hidden-sm-and-down"
          contain
          min-width="100"
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-name-dark.png"
          width="100"
        />
      </div>
    </v-app-bar>

    <v-main>
      <v-container>
        <!-- <posts></posts> -->
        <!-- <shopping-cart></shopping-cart> -->
        <router-link to="/">Home</router-link> |
        <router-link to="/posts">Posts</router-link> |
        <router-link to="/contact">Contact</router-link>

        <router-view />
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
// import Posts from "./components/posts.component.vue";
// import ShoppingCart from "./components/shoppingcart.component.vue";

export default {
  name: "App",

  components: {
    // ShoppingCart,
    // Posts,
  },

  data: () => ({
    //
  }),
};
</script>
