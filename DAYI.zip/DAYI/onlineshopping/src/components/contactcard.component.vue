<template>
  <div>
    <slot></slot>
    <slot name="header"></slot>
    <slot name="details"></slot>
    <slot name="actions"></slot>
  </div>
</template>

<script>
export default {
  name: "ContactCard",
};
</script>

<style scoped>
</style>

// <div class="header">
//       <h2>Person Name</h2>
//     </div>
//     <div class="details">
//       <h3>Age : 35</h3>
//     </div>
//     <div class="actions">
//       <button class="btn btn-danger"><i class="bi bi-trash"></i></button>
//     </div>