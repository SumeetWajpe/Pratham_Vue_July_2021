<template>
  <div>
    <h1>All Posts</h1>

    <div v-for="post in allPosts" :key="post.id">
      <v-alert border="left" color="indigo" dark>
        {{ post.title }}
      </v-alert>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Posts",
  data() {
    return {
      allPosts: [],
    };
  },
  mounted() {
    // ajax
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => (this.allPosts = response.data));
  },
};
</script>

<style scoped>
</style>