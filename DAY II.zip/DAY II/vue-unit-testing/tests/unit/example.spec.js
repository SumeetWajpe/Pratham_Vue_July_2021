import { shallowMount } from '@vue/test-utils'
import HelloWorld from '@/components/HelloWorld.vue'
import Vue from 'vue';

describe('HelloWorld.vue', () => {
  it('renders props.msg when passed', () => {
    const msg = 'new message'
    const wrapper = shallowMount(HelloWorld, {
      propsData: { msg }
    })
    expect(wrapper.text()).toMatch(msg)
  })

  it('renders props.msg of h1 when passed', () => {
    const msg = 'Hello World'
    const wrapper = shallowMount(HelloWorld, {
      propsData: { msg }
    });
    let theH1 = wrapper.find('h1');
    expect(theH1.text()).toMatch(msg);
  })

  it('renders intial value of count as 0', () => {    
    const wrapper = shallowMount(HelloWorld);
    let thePara = wrapper.find('p');
    expect(thePara.text()).toEqual('0');
  })

  it('renders incremented value of count as 1', (done) => {    
    const wrapper = shallowMount(HelloWorld);
    let theButton = wrapper.find('#btnIncrement');
    theButton.trigger('click');

    Vue.nextTick(() => {
      let thePara = wrapper.find('p');
      expect(thePara.text()).toEqual('1');
      done();
    })
    
  })
})
