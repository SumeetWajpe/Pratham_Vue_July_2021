<template>
  <div>
    <h1>About Page !</h1>
    <NuxtLogo />
  </div>
</template>
