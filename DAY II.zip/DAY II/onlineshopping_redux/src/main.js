import Vue from "vue";
import App from "./App.vue";
import vuetify from './plugins/vuetify'
import router from './router'
import {store} from '../src/vuex/store';


Vue.config.productionTip = false;

Vue.filter("outofstock", function(value, args) {
  switch (value) {
    case 0:
      return "Out Of Stock !";
    case 1:
      return value + args.substring(0, args.length - 1);
    default:
      return value + " " + args;
  }
});

new Vue({
  vuetify,
  router,
  store,
  render: (h) => h(App)
}).$mount("#app");
