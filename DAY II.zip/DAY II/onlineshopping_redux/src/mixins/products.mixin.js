export const productsMixin ={
    data(){
        return {
            products :['Laptop','Mobile','Lamp','Locks'],
            filterText:""
        }
    },
    computed:{
        filteredProducts(){
            return this.products.filter(p =>p.match(this.filterText))
        }
    }
}