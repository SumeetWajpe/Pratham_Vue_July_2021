<template>
  <div class="productItem">
    <h2>{{ productdetails.title }}</h2>
    <img
      :src="productdetails.ImageUrl"
      height="150px"
      width="250px"
      :alt="productdetails.title"
    />
    <v-rating
      v-model="productdetails.rating"
      color="yellow darken-3"
      background-color="grey darken-1"
      empty-icon="$ratingFull"
      half-increments
      hover
      medium
    ></v-rating>
    <h5>{{ productdetails.price | currency("₹") }}</h5>
    <h5>
      <span :style="productdetails.quantity ? '' : { color: 'red' }">{{
        productdetails.quantity | outofstock("items")
      }}</span>
    </h5>
    <!-- <h5>Rating : {{ productdetails.rating }}</h5> -->

    <button class="btn btn-primary m-1" @click="IncrementLikes">
      <i class="bi bi-hand-thumbs-up"></i> {{ productdetails.likes }}
    </button>
    <button class="btn btn-danger" @click="deleteProduct(productdetails.id)">
      <i class="bi bi-trash"></i> Delete
    </button>
  </div>
</template>

<script>
import { mapActions } from "vuex";

export default {
  name: "Product",
  props: {
    productdetails: Object,
  },
  methods: {
    IncrementLikes: function () {
      this.productdetails.likes++;
    },
    ...mapActions(['deleteProduct'])
    
  },

  filters: {
    currency(value, args) {
      return `${args} ${value}`;
    },
  },
};
</script>

<style scoped>
.productItem {
  border: 1px solid gray;
  border-radius: 5px;
  box-shadow: 10px 10px 5px lightgray;
  padding: 10px;
  margin: 10px;
}
</style>