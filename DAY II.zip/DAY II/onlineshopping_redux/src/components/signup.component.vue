<template>
    <v-card class="px-10 py-10 my-10">
        <h1>Sign Up :</h1>
        Username : <input type="text"> <br>
        Password : <input type="text"> <br>
        Confirm Password : <input type="password"><br>
        Email : <input type="email">
        <v-btn color="success">Sign Up</v-btn>
    </v-card>
</template>

<script>
    export default {       
    }
</script>

<style scoped>

</style>