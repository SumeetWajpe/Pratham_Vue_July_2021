<template>
    <div>
        <h2>Flipkart </h2>
        <ul>
            <li v-for="product in products" :key="product">{{product}}</li>
        </ul>

        <input type="button" @click="products.push('Computer')" value="Add" />
    </div>
</template>

<script>
import {  productsMixin } from "../mixins/products.mixin";
    export default {
        mixins:[productsMixin],
        data(){
            return {
                isSaleOn:true
            }
        }
    }
</script>

<style scoped>

</style>