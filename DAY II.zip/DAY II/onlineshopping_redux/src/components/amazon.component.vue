<template>
    <div>
        <h2>Amazon </h2>

        Search Here : <input type="text" v-model="filterText" />

        <ul>
            <li v-for="product in filteredProducts" :key="product">{{product}}</li>
        </ul>

    </div>
</template>

<script>
import {  productsMixin } from "../mixins/products.mixin";
    export default {
        mixins:[productsMixin]
    }
</script>

<style scoped>

</style>