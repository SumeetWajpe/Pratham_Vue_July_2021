<template>
    <div>
        <h1>Shopping Providers</h1>
        <amazon></amazon>
        <flipkart></flipkart>
    </div>
</template>

<script>
import Amazon from "./amazon.component.vue";
import Flipkart from "./flipkart.component.vue";

    export default {
        components:{
            Amazon,Flipkart
        }
    }
</script>

<style scoped>

</style>