<template>
  <div>
    <h2>Shopping Cart</h2>

    <v-row>
      <v-col cols="12" sm="4" v-for="product in getAllProducts" :key="product.id">
        <product :productdetails="product" >
        </product>
      </v-col>
    </v-row>
  
  </div>
</template>

<script>
import Product from "./product.component.vue";
import { mapGetters } from "vuex";


export default {
  name: "ShoppingCart",
  components: {
    Product,
  },
  computed:{
            ...mapGetters(['getAllProducts'])

  } ,
  
};
</script>

<style>
</style>


 