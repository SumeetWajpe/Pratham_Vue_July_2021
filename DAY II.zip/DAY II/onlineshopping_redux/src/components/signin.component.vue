<template>
    <v-card class="px-10 py-10 my-10">
        <h1>Sign In :</h1>
        Username : <input type="text" v-model="input.username"> <br>
        Password : <input type="password" v-model="input.password"> <br>       
        <v-btn color="success" @click="login()">Sign In</v-btn>
    </v-card>
</template>

<script>
    export default {
        data(){
            return {
                input:{
                    username:"",
                    password:""
                }
            }
        },
       methods:{
           login(){
               if(this.input.username === "admin" && this.input.password == "admin"){
                   this.$store.dispatch('setAuthentication',true);
                   this.$router.replace({name:'Dashboard'});
               }else{
                   alert("The Usrname / Password in incorrect !")
               }
           }
       }
    }
</script>

<style scoped>

</style>