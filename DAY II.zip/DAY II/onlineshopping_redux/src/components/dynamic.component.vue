<template>
    <div>
        <v-btn color="primary white--text m-1" @click="componentToBeCreated='signup'">Sign Up</v-btn>
        <v-btn color="primary white--text m-1" @click="componentToBeCreated='signin'">Sign In</v-btn>

        <transition name="bounce">
            <keep-alive>
                <component :is="componentToBeCreated"></component>
            </keep-alive>
        </transition>

    </div>
</template>

<script>
import SignIn from "./signin.component.vue";
import SignUp from "./signup.component.vue";

    export default {
        name:'DynamicComponent',
        components:{
        'signin':SignIn,
        'signup':SignUp,
        },
        data(){
            return {
                componentToBeCreated :'signin'
            }
        }
    }
</script>

<style scoped>
    .bounce-enter-active{
        animation: bounce-in .3s;
    }
    .bounce-leave-active{
        animation: bounce-in .3s  reverse;
    }

    @keyframes bounce-in{
        0%{
            transform: scale(0);
        }
        50%{
            transform: scale(1.2);
        }
         100%{
            transform: scale(1);
        }
    }
</style>