import Vue from "vue";
import VueRouter from "vue-router";
import ShoppingCart from "../components/shoppingcart.component.vue";
import Posts from "../components/posts.component.vue";
import Contact from "../components/contact.component.vue";
import PostDetails from "../components/postdetails.component.vue";
import Dashboard from "../components/dashboard.component.vue";
import DynamicComponent from "../components/dynamic.component.vue";
import ShoppingServiceProviders from '../components/shoppingProviders.component.vue'
import {store} from '../vuex/store';


// import Home from '../views/Home.vue'

Vue.use(VueRouter);

// const routes = [
//   {
//     path: "/",
//     name: "Home",
//     component: ShoppingCart,
//   },
//   {
//     path: "/posts",
//     name: "Posts",
//     component: Posts,
//   },
//   {
//     path: "/postdetails/:id",
//     name: "PostDetails",
//     component: PostDetails,
//   },
//   {
//     path: "/contact",
//     name: "Contact",
//     component: Contact,
//   },
//   {
//     path: "*",
//     name: "Universal",
//     component: ShoppingCart, // ErrorComponent
//   },
//   // {
//   //   path: '/about',
//   //   name: 'About',
//   //   // route level code-splitting
//   //   // this generates a separate chunk (about.[hash].js) for this route
//   //   // which is lazy-loaded when the route is visited.
//   //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
//   // }
// ];


const routes = [
  {
    path:'/',
    component:DynamicComponent
  },
  {
    path:'/dashboard',
    component:Dashboard,
    children:[
      {path:'',component:ShoppingCart,name:'Dashboard'},
      {path:'posts',component:Posts,name:'Posts',children:[    
        {path:'postdetails/:id',component:PostDetails,name:'PostDetails'},
      ]},
     
      {path:'contact',component:Contact,name:'Contact'},
      {
        path:'providers',
        component:ShoppingServiceProviders
      }
    ],
    beforeEnter(to,from,next){
      if(store.state.isAuthenticated == false){
        next('/');
      }else{
        next();// normal flow
      }
    }
  },
];


const router = new VueRouter({
  mode: "history",
  routes,
});

export default router;
