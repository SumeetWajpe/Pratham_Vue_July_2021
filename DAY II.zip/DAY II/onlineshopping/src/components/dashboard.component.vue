<template>
    <div>
        <router-link to="/dashboard">Shopping Cart</router-link> |
        <router-link to="/dashboard/posts">Posts</router-link> |
        <router-link to="/dashboard/contact">Contact</router-link>
        <!-- <h1>Dashboard</h1> -->
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name:'Dashboard'
    }
</script>

<style scoped>

</style>

