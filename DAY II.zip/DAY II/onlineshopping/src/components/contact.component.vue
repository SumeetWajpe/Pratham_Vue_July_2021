<template>
  <div>
    <contact-card>
      <template v-slot:header>
        <h1>First Person Name</h1>
      </template>
      <template v-slot:details>
        <h5>Age: 35</h5>
        <h5>City: Pune</h5>
        <h5>State: Maharashtra</h5>
      </template>
      <template v-slot:actions>
        <button class="btn btn-danger"><i class="bi bi-trash"></i></button>
      </template>
    </contact-card>
    <hr />
    <contact-card>
      <template v-slot:header>
        <h1>Second Person Name</h1>
      </template>
      <template v-slot:details>
        <h5>Age: 30</h5>
        <h5>City: Mumbai</h5>
        <h5>State: Maharashtra</h5>
      </template>
      <template v-slot:actions>
        <button class="btn btn-danger"><i class="bi bi-trash"></i></button>
        <button class="btn btn-primary">
          <i class="bi bi-hand-thumbs-up"></i>
        </button>
      </template>
    </contact-card>
    <hr />
    <contact-card>
      <template v-slot:header>
        <h1>Third Person Name</h1>
      </template>
      <template v-slot:details>
        <h5>Age: 30</h5>
        <h5>City: Mumbai</h5>
        <h5>State: Maharashtra</h5>
      </template>
    </contact-card>
  </div>
</template>

<script>
import ContactCard from "./contactcard.component.vue";
export default {
  components: { ContactCard },
  name: "Contact",
};
</script>

<style scoped>
</style>