<template>
  <div>
    <h1>All Posts</h1>

    <v-row>
      <v-col class="col-md-7">
        <div v-for="post in allPosts" :key="post.id" >
      <v-alert border="left" color="indigo" dark>
      <router-link :to="{name:'PostDetails',params:{id:post.id}}">
          {{ post.title }}
      </router-link>
      </v-alert>
    </div>
      </v-col>
      <v-col class="col-md-5">
        <router-view :key="$route.path"> 
              
       </router-view>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "Posts",
  components:{
    
  },
  data() {
    return {
      allPosts: [],
    };
  },
  mounted() {
    // ajax
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => (this.allPosts = response.data));
  },
};
</script>

<style scoped>
  a{
    color: white !important;
    text-decoration: none;
  }
</style>