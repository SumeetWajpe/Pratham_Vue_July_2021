<template>
    <div>
        <h1>Post Details for {{postid}}</h1>
        <hr>
        <div class="postDetails">
            <strong>Post Id :</strong> {{thePost.id}} <br>
            <strong>Post User Id :</strong> {{thePost.userId}} <br>
            <strong>Post Title :</strong> {{thePost.title}} <br>
            <strong>Post Body :</strong> {{thePost.body}} <br>
        </div>
        <!-- <v-btn color="success" @click="GoBack">
            Go Back
        </v-btn> -->
    </div>
</template>

<script>
import axios from 'axios';
    export default {
        name:'PostDetails',
        mounted(){
            axios.get('https://jsonplaceholder.typicode.com/posts/'+this.postid)
            .then(response => this.thePost =  response.data);
        },
        data(){
            return{
                postid: this.$route.params.id,
                thePost:{}
            }
        },
        methods:{
            GoBack(){
                this.$router.go(-1);
            }
        }
    }
</script>

<style scoped>
    .postDetails{
        border: 2px solid grey;
        border-radius: 10px;
        padding: 10px;
        margin: 10px;
    }
    button{
         padding: 10px;
        margin: 10px;
    }
</style>